return {
    hotspot = {},
    game_width = 240,
    game_height = 135,
    scale = 6,

    key = {
        skip = ".",
        cutscene = "escape",
    },
    skip_with_left = false,
    skip_with_right = false,
}