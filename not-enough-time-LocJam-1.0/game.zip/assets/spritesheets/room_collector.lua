return {
  {
    {
      name = "Ruote1",
      x = 222,
      y = 86,
      w = 164,
      h = 22,
      orig_w = 240,
      orig_h = 135,
      offset_x = 32,
      offset_y = 97
    },
    {
      name = "Ruote2",
      x = 222,
      y = 62,
      w = 164,
      h = 22,
      orig_w = 240,
      orig_h = 135,
      offset_x = 32,
      offset_y = 97
    },
    {
      name = "collector",
      x = 391,
      y = 46,
      w = 17,
      h = 62,
      orig_w = 240,
      orig_h = 135,
      offset_x = 85,
      offset_y = 36
    },
    {
      name = "drawer_closed",
      x = 2,
      y = 6,
      w = 7,
      h = 9,
      orig_w = 240,
      orig_h = 135,
      offset_x = 214,
      offset_y = 80
    },
    {
      name = "drawer_open",
      x = 233,
      y = 30,
      w = 7,
      h = 9,
      orig_w = 240,
      orig_h = 135,
      offset_x = 214,
      offset_y = 80
    },
    {
      name = "foreground",
      x = 222,
      y = 41,
      w = 167,
      h = 19,
      orig_w = 240,
      orig_h = 135,
      offset_x = 31,
      offset_y = 92
    },
    {
      name = "navigator",
      x = 11,
      y = 11,
      w = 9,
      h = 4,
      orig_w = 240,
      orig_h = 135,
      offset_x = 178,
      offset_y = 79
    },
    {
      name = "pick",
      x = 2,
      y = 2,
      w = 2,
      h = 2,
      orig_w = 240,
      orig_h = 135,
      offset_x = 56,
      offset_y = 43
    },
    {
      name = "poster",
      x = 410,
      y = 61,
      w = 26,
      h = 47,
      orig_w = 240,
      orig_h = 135,
      offset_x = 45,
      offset_y = 34
    },
    {
      name = "poster_pick",
      x = 410,
      y = 12,
      w = 26,
      h = 47,
      orig_w = 240,
      orig_h = 135,
      offset_x = 45,
      offset_y = 34
    },
    {
      name = "recorder",
      x = 222,
      y = 22,
      w = 9,
      h = 17,
      orig_w = 240,
      orig_h = 135,
      offset_x = 120,
      offset_y = 62
    },
    {
      name = "van",
      x = 2,
      y = 17,
      w = 218,
      h = 91,
      orig_w = 240,
      orig_h = 135,
      offset_x = 9,
      offset_y = 20
    },
    filename = "room_collector.png"
  }
}