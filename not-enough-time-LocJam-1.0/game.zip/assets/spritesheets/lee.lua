return {
  {
    {
      name = "remote1",
      x = 2,
      y = 57,
      w = 54,
      h = 53,
      orig_w = 240,
      orig_h = 135,
      offset_x = 160,
      offset_y = 45
    },
    {
      name = "remote10",
      x = 170,
      y = 2,
      w = 54,
      h = 53,
      orig_w = 240,
      orig_h = 135,
      offset_x = 160,
      offset_y = 45
    },
    {
      name = "remote11",
      x = 226,
      y = 57,
      w = 54,
      h = 53,
      orig_w = 240,
      orig_h = 135,
      offset_x = 160,
      offset_y = 45
    },
    {
      name = "remote12",
      x = 226,
      y = 2,
      w = 54,
      h = 53,
      orig_w = 240,
      orig_h = 135,
      offset_x = 160,
      offset_y = 45
    },
    {
      name = "remote13",
      x = 226,
      y = 2,
      w = 54,
      h = 53,
      orig_w = 240,
      orig_h = 135,
      offset_x = 160,
      offset_y = 45
    },
    {
      name = "remote14",
      x = 226,
      y = 2,
      w = 54,
      h = 53,
      orig_w = 240,
      orig_h = 135,
      offset_x = 160,
      offset_y = 45
    },
    {
      name = "remote2",
      x = 2,
      y = 2,
      w = 54,
      h = 53,
      orig_w = 240,
      orig_h = 135,
      offset_x = 160,
      offset_y = 45
    },
    {
      name = "remote3",
      x = 58,
      y = 57,
      w = 54,
      h = 53,
      orig_w = 240,
      orig_h = 135,
      offset_x = 160,
      offset_y = 45
    },
    {
      name = "remote4",
      x = 58,
      y = 2,
      w = 54,
      h = 53,
      orig_w = 240,
      orig_h = 135,
      offset_x = 160,
      offset_y = 45
    },
    {
      name = "remote5",
      x = 114,
      y = 57,
      w = 54,
      h = 53,
      orig_w = 240,
      orig_h = 135,
      offset_x = 160,
      offset_y = 45
    },
    {
      name = "remote6",
      x = 114,
      y = 57,
      w = 54,
      h = 53,
      orig_w = 240,
      orig_h = 135,
      offset_x = 160,
      offset_y = 45
    },
    {
      name = "remote7",
      x = 114,
      y = 57,
      w = 54,
      h = 53,
      orig_w = 240,
      orig_h = 135,
      offset_x = 160,
      offset_y = 45
    },
    {
      name = "remote8",
      x = 114,
      y = 2,
      w = 54,
      h = 53,
      orig_w = 240,
      orig_h = 135,
      offset_x = 160,
      offset_y = 45
    },
    {
      name = "remote9",
      x = 170,
      y = 57,
      w = 54,
      h = 53,
      orig_w = 240,
      orig_h = 135,
      offset_x = 160,
      offset_y = 45
    },
    {
      name = "stand",
      x = 2,
      y = 57,
      w = 54,
      h = 53,
      orig_w = 240,
      orig_h = 135,
      offset_x = 160,
      offset_y = 45
    },
    {
      name = "talk1",
      x = 282,
      y = 57,
      w = 54,
      h = 53,
      orig_w = 240,
      orig_h = 135,
      offset_x = 160,
      offset_y = 45
    },
    {
      name = "talk2",
      x = 282,
      y = 57,
      w = 54,
      h = 53,
      orig_w = 240,
      orig_h = 135,
      offset_x = 160,
      offset_y = 45
    },
    {
      name = "talk3",
      x = 282,
      y = 2,
      w = 54,
      h = 53,
      orig_w = 240,
      orig_h = 135,
      offset_x = 160,
      offset_y = 45
    },
    {
      name = "talk4",
      x = 338,
      y = 57,
      w = 54,
      h = 53,
      orig_w = 240,
      orig_h = 135,
      offset_x = 160,
      offset_y = 45
    },
    {
      name = "talk5",
      x = 338,
      y = 57,
      w = 54,
      h = 53,
      orig_w = 240,
      orig_h = 135,
      offset_x = 160,
      offset_y = 45
    },
    {
      name = "talk6",
      x = 282,
      y = 2,
      w = 54,
      h = 53,
      orig_w = 240,
      orig_h = 135,
      offset_x = 160,
      offset_y = 45
    },
    {
      name = "talk7",
      x = 2,
      y = 57,
      w = 54,
      h = 53,
      orig_w = 240,
      orig_h = 135,
      offset_x = 160,
      offset_y = 45
    },
    {
      name = "talk8",
      x = 2,
      y = 57,
      w = 54,
      h = 53,
      orig_w = 240,
      orig_h = 135,
      offset_x = 160,
      offset_y = 45
    },
    filename = "lee.png"
  }
}