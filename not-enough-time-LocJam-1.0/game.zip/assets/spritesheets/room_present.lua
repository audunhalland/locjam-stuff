return {
  {
    {
      name = "Ruote1",
      x = 486,
      y = 24,
      w = 164,
      h = 22,
      orig_w = 240,
      orig_h = 135,
      offset_x = 32,
      offset_y = 97
    },
    {
      name = "Ruote2",
      x = 652,
      y = 25,
      w = 164,
      h = 22,
      orig_w = 240,
      orig_h = 135,
      offset_x = 32,
      offset_y = 97
    },
    {
      name = "clouds",
      x = 244,
      y = 4,
      w = 240,
      h = 41,
      orig_w = 240,
      orig_h = 135,
      offset_x = 0,
      offset_y = 5
    },
    {
      name = "drawer_closed",
      x = 486,
      y = 13,
      w = 7,
      h = 9,
      orig_w = 240,
      orig_h = 135,
      offset_x = 214,
      offset_y = 80
    },
    {
      name = "drawer_open",
      x = 486,
      y = 2,
      w = 7,
      h = 9,
      orig_w = 240,
      orig_h = 135,
      offset_x = 214,
      offset_y = 80
    },
    {
      name = "exterior",
      x = 244,
      y = 47,
      w = 225,
      h = 93,
      orig_w = 240,
      orig_h = 135,
      offset_x = 5,
      offset_y = 20
    },
    {
      name = "foreground",
      x = 861,
      y = 33,
      w = 48,
      h = 55,
      orig_w = 240,
      orig_h = 135,
      offset_x = 160,
      offset_y = 56
    },
    {
      name = "navigator",
      x = 495,
      y = 18,
      w = 9,
      h = 4,
      orig_w = 240,
      orig_h = 135,
      offset_x = 178,
      offset_y = 79
    },
    {
      name = "sky",
      x = 2,
      y = 5,
      w = 240,
      h = 135,
      orig_w = 240,
      orig_h = 135,
      offset_x = 0,
      offset_y = 0
    },
    {
      name = "trees",
      x = 861,
      y = 90,
      w = 240,
      h = 50,
      orig_w = 240,
      orig_h = 135,
      offset_x = 0,
      offset_y = 36
    },
    {
      name = "tunnel_front",
      x = 628,
      y = 48,
      w = 11,
      h = 92,
      orig_w = 11,
      orig_h = 135,
      offset_x = 0,
      offset_y = 0
    },
    {
      name = "tunnel_pattern",
      x = 471,
      y = 48,
      w = 155,
      h = 92,
      orig_w = 155,
      orig_h = 135,
      offset_x = 0,
      offset_y = 0
    },
    {
      name = "van",
      x = 641,
      y = 49,
      w = 218,
      h = 91,
      orig_w = 240,
      orig_h = 135,
      offset_x = 9,
      offset_y = 20
    },
    filename = "room_present.png"
  }
}